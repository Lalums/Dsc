﻿Configuration IISwebsite
{

Param ([string] $Machinename)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node localhost
  {
  
    WindowsFeature IIS {
        
           	Ensure          = "Present"
            	Name            = "Web-Server"
        }       
       
       	WindowsFeature Management {

            	Name = 'Web-Mgmt-Service'
            	Ensure = 'Present'
            	DependsOn = @('[WindowsFeature]IIS')
        }
    
      	WindowsFeature ASP
    	{
      		Ensure = “Present”
      		Name = “Web-Asp-Net45”
    	}
	
	WindowsFeature WebServerManagementConsole
    	{
        	Name = "Web-Mgmt-Console"
        	Ensure = "Present"
		DependsOn = @('[WindowsFeature]IIS')
    	}

     Script welcome
    {
        TestScript = {
            Test-Path "C:\inetpub\wwwroot\mynewpage.html"
        }
        SetScript ={
            
            New-Item     C:\inetpub\wwwroot -ItemType Directory -Force

            "<html>
            <h1>
            <title>Thank you</title>
            </H 1>
            <body>
            Hi Team, We are doing good. <br><br>
            <b></b> 
            </body>
            </html>" | Out-File "C:\inetpub\wwwroot\mynewpage.html" -Force
             
        }
        GetScript = {@{Result = "welcome"}}
        DependsOn = "[WindowsFeature]IIS"
    }
  }
}