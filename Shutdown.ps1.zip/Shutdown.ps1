﻿configuration shutdown
    { 
    param ($MachineName)
    Import-DscResource -ModuleName PSDesiredStateConfiguration
 
	Node $MachineName	
      
 {
        script EnsurePresent {
        TestScript = {
            Test-Path "C:\temp1\Reboot.bat"
                       }
        SetScript ={
            if (!(Test-Path "C:\temp1")){
                New-Item     C:\temp1 -ItemType Directory -Force
            }
        "shutdown -r -t 00 -f" | Out-File "C:\temp1\Reboot.bat" -Force
            
            }
        GetScript = {@{Result = "EnsurePresent"}}
 }
 }
 }

    
    