﻿configuration Regedit
    {
    param ($MachineName)
 
	Node $MachineName
    
      {    
        Registry "DisableTLSserver 1.0" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "DisableTLSClient 1.0" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "DisableTLSserver 1.1" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "DisableTLSClient 1.1" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
        Registry "EnableTLSserver 1.2" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
        ValueName = "DisabledByDefault"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "EnableTLSclient 1.2" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'
        ValueName = "DisabledByDefault"
        ValueData = "0"
        ValueType = "Dword"
        }

#Installing AD Tool
       WindowsFeature ADTools
        {
        Name = "RSAT-ADDS-Tools"
        Ensure = "Present"
        }

# Shutdown File creation

Script EnsurePresent
 {
        TestScript = {
            Test-Path "C:\temp\Reboot.bat"
        }
        SetScript ={
            if (!(Test-Path "C:\temp")){
                New-Item     C:\temp -ItemType Directory -Force
            }
        "shutdown -r -t 00 -f" | Out-File "C:\temp\Reboot.bat" -Force
            
        }
        GetScript = {@{Result = "EnsurePresent"}}
        }
            
      }
      }
    
 
 # DisableFirewall

 Script DisableFirewall 
{
    GetScript = {
        @{
            GetScript = $GetScript
            SetScript = $SetScript
            TestScript = $TestScript
            Result = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
        }
    }

    SetScript = {
        Set-NetFirewallProfile -All -Enabled False -Verbose
    }

    TestScript = {
        $Status = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
        $Status -eq $True
    }
}
