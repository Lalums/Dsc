﻿configuration Regeditsettings
    {
    param ($MachineName)
    Import-DscResource -ModuleName PSDesiredStateConfiguration
 
	Node $MachineName	
    
      {    
        Registry "DisableTLSserver 1.0" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "DisableTLSClient 1.0" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "DisableTLSserver 1.1" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "DisableTLSClient 1.1" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client'
        ValueName = "Enabled"
        ValueData = "0"
        ValueType = "Dword"
        }
        Registry "EnableTLSserver 1.2" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
        ValueName = "DisabledByDefault"
        ValueData = "0"
        ValueType = "Dword"
        }
       Registry "EnableTLSclient 1.2" {
        Ensure = "Present"
        Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'
        ValueName = "DisabledByDefault"
        ValueData = "0"
        ValueType = "Dword"
        }

#Installing AD Tool
       WindowsFeature ADTools
        {
        Name = "RSAT-ADDS-Tools"
        Ensure = "Present"
        }
        }
        }

