﻿configuration Copyandunzip
{ 
    
    param ($MachineName)
  
    Node $MachineName
    { 
        
        File DirectoryCopy
        {
            Ensure = "Present"
            Type = "Directory"
            Recurse = $true
            SourcePath = "https://github.com/Lalums/Dsc/blob/master/xWebAdministration.zip?raw=true"
            DestinationPath = "C:\Program Files\WindowsPowerShell\Modules" 
        }

        archive ZipFile
        {
            Path = "C:\Program Files\WindowsPowerShell\Modules\xWebAdministration.zip"
            Destination = "C:\Program Files\WindowsPowerShell\Modules"
            DependsOn = "[File]DirectoryCopy"
 
        }    
 
        
    } 
}