﻿configuration Foldercreation
    { 
	param ($MachineName)
 
	Node $MachineName
        {
          File CreateFile {
            Type = 'Directory'
            DestinationPath = 'C:\lalu'
            Ensure = "Present"
            }
        }
    }