﻿Configuration IISwebsite
{

Param ([string] $Machinename)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node localhost
  {
  
    WindowsFeature IIS {
        
           	Ensure          = "Present"
            	Name            = "Web-Server"
        }       
       
       	WindowsFeature Management {

            	Name = 'Web-Mgmt-Service'
            	Ensure = 'Present'
            	DependsOn = @('[WindowsFeature]IIS')
        }
    
      	WindowsFeature ASP
    	{
      		Ensure = “Present”
      		Name = “Web-Asp-Net45”
    	}
	
	WindowsFeature WebServerManagementConsole
    	{
        	Name = "Web-Mgmt-Console"
        	Ensure = "Present"
		DependsOn = @('[WindowsFeature]IIS')
    	}
     }
}